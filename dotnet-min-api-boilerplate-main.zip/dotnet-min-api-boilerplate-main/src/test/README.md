# dotnet-minapi-boilerplate
dotnet 8 minimal API boilerplate project template
